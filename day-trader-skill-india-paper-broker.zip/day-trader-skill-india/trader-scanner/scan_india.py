#!/usr/bin/env python3
"""India cash-equity scanner: daily setups or a 15-minute opening-range check."""
import argparse
import datetime as dt
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india

OUT = "trader/watchlist.json"
UNIVERSE = "trader/india_universe.txt"


def daily_setups(bars):
    closes = [float(x["close"]) for x in bars if x.get("close") is not None]
    if len(closes) < 22:
        return []
    last = closes[-1]
    signals = []
    if last > max(closes[-21:-1]):
        signals.append("breakout_20d_close")
    avg = sum(closes[-20:]) / 20
    prev_avg = sum(closes[-21:-1]) / 20
    if closes[-2] <= prev_avg and last > avg:
        signals.append("reclaim_sma20")
    strength = india.rsi(closes, 14)
    if strength is not None and strength < 30:
        signals.append("rsi14_oversold")
    return signals


def opening_range(bars, day):
    today = [b for b in bars if b["date"] == day and "09:15" <= b["hhmm"] < "09:30"]
    today.sort(key=lambda b: b["hhmm"])
    if len(today) < 3:
        return None
    return {"high": max(float(b["high"]) for b in today),
            "low": min(float(b["low"]) for b in today), "bars": today}


def scan(symbols, mode, now_utc, offline=None, limit=None, pause=0.35, exchange="NSE"):
    local = india.to_ist(now_utc)
    day = local.date().isoformat()
    status = india.is_open(now_utc)
    hits, errors = [], []
    selected = symbols[:limit] if limit else symbols
    for i, symbol in enumerate(selected):
        try:
            doc = india.chart_doc(symbol, "1d" if mode == "daily" else "5m",
                                  "6mo" if mode == "daily" else "5d", offline=offline, exchange=exchange)
            bars = doc["bars"]
            if mode == "daily":
                past = [b for b in bars if b["date"] < day]
                signals = daily_setups(past)
                if signals:
                    hits.append({"symbol": symbol, "yahoo_symbol": doc["yahoo_symbol"],
                                 "price": past[-1]["close"], "currency": doc["currency"],
                                 "setups": signals, "bar_date": past[-1]["date"]})
            else:
                done = india.completed_bars(bars, now_utc, 5)
                op = opening_range(done, day)
                if not op:
                    continue
                later = [b for b in done if b["date"] == day and b["hhmm"] >= "09:30"]
                for bar in later:
                    if float(bar["close"]) > op["high"]:
                        hits.append({"symbol": symbol, "yahoo_symbol": doc["yahoo_symbol"],
                                     "price": bar["close"], "currency": doc["currency"],
                                     "setups": ["opening_range_breakout_15m"], "date": day,
                                     "entry_time_ist": bar["time"], "range_high": round(op["high"], 4),
                                     "range_low": round(op["low"], 4), "volume": bar["volume"]})
                        break
        except india.IndiaDataError as e:
            errors.append({"symbol": symbol, "error": str(e)})
        if not offline and i + 1 < len(selected):
            time.sleep(max(0.0, pause))
    hits.sort(key=lambda h: float(h.get("volume") or 0) * float(h["price"]), reverse=True)
    return {"market": "India NSE/BSE cash equities", "mode": mode, "as_of_ist": local.isoformat(),
            "session": status, "universe_count": len(symbols), "scanned": len(selected),
            "partial": len(selected) != len(symbols) or bool(errors), "hits": hits, "errors": errors,
            "disclaimer": "Unofficial Yahoo data; candidates are not recommendations."}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("daily", "orb"))
    p.add_argument("--symbols", help="comma-separated NSE/BSE symbols")
    p.add_argument("--universe", default=UNIVERSE, help="one exchange symbol per line")
    p.add_argument("--exchange", choices=("NSE", "BSE"), default="NSE")
    p.add_argument("--now", help="ISO time; offset-free values are IST")
    p.add_argument("--offline", help="offline folder with SYMBOL.json Yahoo chart fixtures")
    p.add_argument("--limit", type=int, default=50, help="symbols per scan (default 50 to limit requests)")
    p.add_argument("--pause", type=float, default=0.35)
    p.add_argument("--out", default=OUT)
    p.add_argument("--no-write", action="store_true")
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)
    try:
        symbols = [x.strip().upper() for x in a.symbols.split(",") if x.strip()] if a.symbols else india.load_symbols(a.universe)
        result = scan(symbols, a.mode, india.parse_now(a.now), a.offline, a.limit, a.pause, a.exchange)
        result["exchange"] = a.exchange
        if not a.no_write:
            india.write_json(a.out, result)
        if a.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print("India %s scan: %d checked, %d matches%s." %
                  (a.mode, result["scanned"], len(result["hits"]), " (partial)" if result["partial"] else ""))
            for hit in result["hits"]:
                print("%-16s %-32s ₹%s %s" % (hit["symbol"], ", ".join(hit["setups"]), hit["price"], hit.get("entry_time_ist", "")))
            if result["errors"]:
                print("Data errors: %d; see JSON output for details." % len(result["errors"]))
            print(result["disclaimer"])
        return 0 if result["hits"] else 1
    except india.IndiaDataError as e:
        print("scan_india: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
