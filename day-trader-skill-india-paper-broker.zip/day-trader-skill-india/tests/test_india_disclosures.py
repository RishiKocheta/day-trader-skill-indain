import importlib.util
import json
import os
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
PATH = os.path.join(ROOT, "trader-pelosi", "india_disclosures.py")
SPEC = importlib.util.spec_from_file_location("india_disclosures", PATH)
india = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(india)


class IndiaDisclosureTests(unittest.TestCase):
    def test_classifies_indian_disclosure_categories(self):
        self.assertIn("promoter/director/designated-person transaction", india.classify({"category": "Promoter sale"}))
        self.assertIn("substantial shareholding / SAST", india.classify({"subject": "SAST acquisition"}))
        self.assertIn("pledge / encumbrance", india.classify({"details": "release of pledge"}))
        self.assertIn("shareholding pattern", india.classify({"type": "Quarterly shareholding pattern"}))
        self.assertEqual(india.classify({"remarks": "routine announcement"}), ["unclassified; inspect source filing"])

    def test_reads_csv_and_json_exports(self):
        with tempfile.TemporaryDirectory() as td:
            csv_path = os.path.join(td, "export.csv")
            with open(csv_path, "w", encoding="utf-8") as f:
                f.write("symbol,subject\nABC,Promoter disclosure\n")
            self.assertEqual(india.load_rows(csv_path)[0]["symbol"], "ABC")
            json_path = os.path.join(td, "export.json")
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump({"data": [{"symbol": "XYZ"}]}, f)
            self.assertEqual(india.load_rows(json_path)[0]["symbol"], "XYZ")


if __name__ == "__main__":
    unittest.main()
