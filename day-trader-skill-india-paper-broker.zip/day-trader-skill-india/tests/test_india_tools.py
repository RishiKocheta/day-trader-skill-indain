import datetime as dt
import os
import sys
import unittest
import importlib.util

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)
from trader_common import india

def load_tool(folder, filename, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, folder, filename))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

class IndiaTools(unittest.TestCase):
    def test_offset_free_time_is_ist_and_symbol_suffix(self):
        now = india.parse_now("2026-10-30 09:15")
        self.assertEqual(india.to_ist(now).strftime("%H:%M"), "09:15")
        self.assertEqual(india.yahoo_symbol("RELIANCE"), "RELIANCE.NS")
        self.assertEqual(india.yahoo_symbol("TCS", "BSE"), "TCS.BO")

    def test_inr_sizing_obeys_risk_cap(self):
        plan = {"symbol": "ABC", "entry": 100, "stop": 95, "target": 105}
        result = load_tool("trader-budget", "size_india.py", "size_india_test").size(
            plan, {"cash_inr": 10000}, risk_pct=1, capital_pct=100, costs_pct=0)
        self.assertEqual(result["quantity"], 20)
        self.assertLessEqual(result["estimated_risk_inr"], result["risk_budget_inr"])
        self.assertTrue(result["paper_only"])

    def test_paper_simulation_guard_requires_risk_approval(self):
        simulate = load_tool("trader-broker", "paper_india.py", "paper_india_test").simulate
        order = {"symbol":"ABC","quantity":1,"entry":10,"paper_only":True,"currency":"INR"}
        with self.assertRaises(ValueError):
            simulate(order, {"approved_for_simulation":False}, 10)
        fill = simulate(order, {"approved_for_simulation":True}, 10)
        self.assertEqual(fill["status"], "SIMULATED_ONLY")
        self.assertFalse(fill["broker_connected"])

    def test_inr_risk_guard_blocks_daily_limit_and_zero_size(self):
        check = load_tool("trader-risk", "check_india.py", "check_india_test").check
        order = {"paper_only": True, "quantity": 0, "currency": "INR"}
        result = check(order, 2500, 0, 2500, 3)
        self.assertFalse(result["approved_for_simulation"])
        self.assertIn("daily loss limit reached", result["reasons"])
        self.assertIn("quantity is zero; risk or capital limit cannot support one share", result["reasons"])

    def test_india_replay_is_seeded_and_requires_twenty_sessions(self):
        mod = load_tool("trader-timemachine", "timemachine_india.py", "time_india_test")
        sessions = {}
        start = dt.date(2026, 1, 1)
        for day_num in range(20):
            day = (start + dt.timedelta(days=day_num)).isoformat()
            sessions[day] = [{"hhmm": "09:%02d" % (15 + i * 5), "open": 100, "high": 101,
                              "low": 99, "close": 100, "volume": 1} for i in range(30)]
        plan = {"entry": 100, "stop": 98, "target": 102, "entry_time_ist": "09:30"}
        a = mod.replay(sessions, plan, replays=50, seed=7)
        b = mod.replay(sessions, plan, replays=50, seed=7)
        self.assertEqual(a["probabilities_pct"], b["probabilities_pct"])
        with self.assertRaises(india.IndiaDataError):
            mod.replay(dict(list(sessions.items())[:19]), plan, replays=10)

if __name__ == "__main__":
    unittest.main()
