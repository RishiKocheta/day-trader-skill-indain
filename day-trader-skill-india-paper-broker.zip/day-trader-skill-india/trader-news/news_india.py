#!/usr/bin/env python3
"""Read locally saved NSE/BSE disclosure rows, or Yahoo Finance news RSS (unofficial)."""
import argparse,csv,json,sys,urllib.request,urllib.parse,xml.etree.ElementTree as ET

def saved_rows(path):
 if path.lower().endswith('.csv'):
  with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 with open(path,encoding='utf8') as f:
  doc=json.load(f);return doc if isinstance(doc,list) else doc.get('data',doc.get('rows',[]))

def yahoo_rss(symbol,timeout=20):
 ticker=symbol.upper() if '.' in symbol else symbol.upper()+'.NS'
 url='https://feeds.finance.yahoo.com/rss/2.0/headline?s='+urllib.parse.quote(ticker)+'&region=IN&lang=en-IN'
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
 with urllib.request.urlopen(req,timeout=timeout) as r: root=ET.fromstring(r.read())
 return [{'title':x.findtext('title',''),'link':x.findtext('link',''),'published':x.findtext('pubDate',''),'source':'Yahoo Finance RSS (unofficial)'} for x in root.findall('./channel/item')]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--symbol');p.add_argument('--file',help='locally saved NSE/BSE CSV or JSON disclosures');a=p.parse_args()
 try:
  rows=saved_rows(a.file) if a.file else yahoo_rss(a.symbol) if a.symbol else None
  if rows is None: p.error('provide --file or --symbol')
  print(json.dumps(rows,ensure_ascii=False,indent=2));return 0
 except (OSError,ValueError,KeyError,ET.ParseError) as e:print('news_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
