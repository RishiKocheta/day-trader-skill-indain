#!/usr/bin/env python3
"""Validate an India INR proposal against daily loss and trade-count limits."""
import argparse,json,sys,os
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india

def check(order, daily_loss, trades, max_daily_loss, max_trades):
 reasons=[]
 if order.get('paper_only') is not True: reasons.append('proposal is not marked paper_only')
 if int(order.get('quantity',0))<=0: reasons.append('quantity is zero; risk or capital limit cannot support one share')
 if float(daily_loss)>=float(max_daily_loss): reasons.append('daily loss limit reached')
 if int(trades)>=int(max_trades): reasons.append('maximum trades reached')
 if order.get('currency')!='INR': reasons.append('currency must be INR')
 return {'approved_for_simulation':not reasons,'reasons':reasons,'paper_only':True,'currency':'INR'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--order',default='trader/order-india.json');p.add_argument('--daily-loss',type=float,default=0);p.add_argument('--max-daily-loss',type=float,required=True);p.add_argument('--trades',type=int,default=0);p.add_argument('--max-trades',type=int,default=3);p.add_argument('--out',default='trader/risk-india.json');a=p.parse_args()
 try:
  with open(a.order,encoding='utf8') as f:order=json.load(f)
  result=check(order,a.daily_loss,a.trades,a.max_daily_loss,a.max_trades);india.write_json(a.out,result);print(json.dumps(result,indent=2));return 0 if result['approved_for_simulation'] else 1
 except (OSError,ValueError,KeyError) as e:print('check_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
