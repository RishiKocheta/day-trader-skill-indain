#!/usr/bin/env python3
"""Check an NSE/BSE cash equity against a completed 15-minute opening range."""
import argparse
import datetime as dt
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india


def evaluate(symbol, now_utc, side="buy", offline=None, exchange="NSE"):
    doc = india.chart_doc(symbol, "5m", "5d", offline=offline, exchange=exchange)
    now = india.to_ist(now_utc)
    day = now.date().isoformat()
    bars = india.completed_bars(doc["bars"], now_utc, 5)
    today = [b for b in bars if b["date"] == day]
    opening = [b for b in today if "09:15" <= b["hhmm"] < "09:30"]
    opening.sort(key=lambda b: b["hhmm"])
    if len(opening) < 3:
        return {"status": "waiting", "reason": "the 15-minute opening range is not complete",
                "symbol": symbol.upper(), "date": day, "timezone": "Asia/Kolkata"}
    high = max(float(b["high"]) for b in opening)
    low = min(float(b["low"]) for b in opening)
    direction = "buy" if side == "buy" else "sell"
    after = [b for b in today if b["hhmm"] >= "09:30"]
    for bar in after:
        crossed = float(bar["close"]) > high if direction == "buy" else float(bar["close"]) < low
        if crossed:
            return {"status": "triggered", "symbol": symbol.upper(), "yahoo_symbol": doc["yahoo_symbol"],
                    "side": direction, "date": day, "entry": float(bar["close"]),
                    "entry_time_ist": bar["time"], "opening_range_high": high, "opening_range_low": low,
                    "currency": "INR", "data_currency": doc["currency"],
                    "source": doc["source"], "data_as_of": doc["as_of"],
                    "note": "A completed 5-minute close crossed the opening range; this is not a recommendation."}
    return {"status": "waiting", "symbol": symbol.upper(), "side": direction, "date": day,
            "opening_range_high": high, "opening_range_low": low,
            "reason": "no completed 5-minute close has crossed the range", "currency": "INR",
            "source": doc["source"], "data_as_of": doc["as_of"]}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("symbol")
    p.add_argument("--side", choices=("buy", "sell"), default="buy")
    p.add_argument("--exchange", choices=("NSE", "BSE"), default="NSE")
    p.add_argument("--now", help="ISO time; offset-free values are IST")
    p.add_argument("--offline", help="offline folder or Yahoo chart JSON")
    p.add_argument("--out", default="trader/entry.json")
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)
    try:
        result = evaluate(a.symbol, india.parse_now(a.now), a.side, a.offline, a.exchange)
        if result["status"] == "triggered":
            india.write_json(a.out, result)
        if a.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print("%s: %s%s" % (result["status"].upper(), result.get("reason", ""),
                                 (" at ₹%s (%s IST)" % (result["entry"], result["entry_time_ist"]))
                                 if result["status"] == "triggered" else ""))
        return 0 if result["status"] == "triggered" else 1
    except india.IndiaDataError as e:
        print("entry_india: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
