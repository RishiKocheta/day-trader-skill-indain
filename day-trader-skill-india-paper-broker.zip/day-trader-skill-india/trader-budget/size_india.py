#!/usr/bin/env python3
"""INR cash-equity position sizing; emits a local paper order proposal only."""
import argparse, json, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india

def size(plan, account, risk_pct=0.5, capital_pct=20.0, costs_pct=0.5):
    entry, stop = float(plan['entry']), float(plan['stop'])
    cash=float(account['cash_inr'])
    if cash <= 0 or float(risk_pct) <= 0 or float(capital_pct) <= 0 or float(costs_pct) < 0:
        raise ValueError('cash and risk/capital percentages must be positive; cost buffer cannot be negative')
    if entry <= 0 or stop <= 0 or entry == stop:
        raise ValueError('entry and stop must be positive and different')
    if plan.get('side', 'buy') != 'buy':
        raise ValueError('India paper sizing supports long cash-equity proposals only')
    risk_cap=cash*float(risk_pct)/100
    per_share=abs(entry-stop)+entry*float(costs_pct)/100
    qty=int(min(risk_cap/per_share, cash*float(capital_pct)/100/entry))
    return {'symbol':plan['symbol'],'side':'buy','quantity':qty,'entry':entry,'stop':stop,
      'target':float(plan['target']),'risk_budget_inr':round(risk_cap,2),
      'estimated_risk_inr':round(qty*per_share,2),'estimated_value_inr':round(qty*entry,2),
      'estimated_cost_buffer_inr':round(qty*entry*float(costs_pct)/100,2),
      'currency':'INR','paper_only':True,'source':'local proposal; not sent to broker'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',default='trader/plan-india.json');p.add_argument('--cash',type=float,required=True);p.add_argument('--risk-pct',type=float,default=.5);p.add_argument('--capital-pct',type=float,default=20);p.add_argument('--cost-buffer-pct',type=float,default=.5);p.add_argument('--out',default='trader/order-india.json');a=p.parse_args()
 try:
  with open(a.plan,encoding='utf8') as f: plan=json.load(f)
  result=size(plan,{'cash_inr':a.cash},a.risk_pct,a.capital_pct,a.cost_buffer_pct);india.write_json(a.out,result);print(json.dumps(result,indent=2));return 0
 except (OSError,ValueError,KeyError) as e: print('size_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
