#!/usr/bin/env python3
"""Record a local hypothetical INR fill from an India proposal; never connects to a broker."""
import argparse,json,sys,os,datetime as dt
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india

def simulate(order, risk, price, now=None):
 if not risk.get('approved_for_simulation'): raise ValueError('risk check has not approved simulation')
 if not order.get('paper_only') or order.get('currency')!='INR': raise ValueError('only INR paper proposals are accepted')
 return {'symbol':order['symbol'],'side':'buy','quantity':int(order['quantity']),'fill_price_inr':float(price),
  'proposed_entry_inr':float(order['entry']),'difference_inr':round(float(price)-float(order['entry']),2),
  'status':'SIMULATED_ONLY','paper_only':True,'broker_connected':False,'timestamp_ist':(now or dt.datetime.now(india.IST)).isoformat()}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--order',default='trader/order-india.json');p.add_argument('--risk',default='trader/risk-india.json');p.add_argument('--price',type=float,required=True,help='hypothetical fill price in INR');p.add_argument('--out',default='trader/fill-india.json');a=p.parse_args()
 try:
  with open(a.order,encoding='utf8') as f:o=json.load(f)
  with open(a.risk,encoding='utf8') as f:r=json.load(f)
  result=simulate(o,r,a.price);india.write_json(a.out,result);print(json.dumps(result,indent=2));return 0
 except (OSError,ValueError,KeyError) as e:print('paper_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
