---
name: trader-pelosi
description: >-
  India public-disclosure reader. Classifies saved NSE/BSE disclosure exports
  about promoter/director trades, substantial shareholding, pledges and
  shareholding patterns. The original skill name is retained for compatibility.
  Use when reviewing Indian company disclosures; it does not track US politicians.
argument-hint: "[saved CSV or JSON disclosure export]"
---

# trader-pelosi : India disclosure reader

This skill name is preserved from upstream. Its India mode reads **files the user has saved** from public exchange or company sources. It does not claim that India has an equivalent to US congressional Periodic Transaction Reports. Public filings can be delayed, amended, inconsistently labeled, or unavailable in bulk; the tool cannot guarantee completeness.

```bash
python3 "${CLAUDE_SKILL_DIR}/india_disclosures.py" scan disclosures.csv
python3 "${CLAUDE_SKILL_DIR}/india_disclosures.py" new disclosures.json --state trader/state/india-disclosures.json
```

The reader preserves each source row and adds broad categories when text matches:

- promoter, director, designated-person or insider transaction;
- substantial shareholding / SAST acquisition or disposal;
- pledge, invocation, release or other encumbrance;
- periodic shareholding pattern.

The categories are search aids, not regulatory determinations. Review the original filing, issuer, date, transaction type, holding before/after, and applicable exchange/SEBI rules. Keep the source URL and filing date with the saved export. Do not infer motive, inside information, or future returns from a disclosure. A disclosure is not a trading signal or recommendation.

The original US parser `ptr.py` and its fixtures remain for upstream compatibility and historical tests; they concern House Clerk PTRs and are **not** India functionality. Do not use them as a source for Indian disclosures.

This tool only reads local CSV/JSON and writes a local fingerprint state file for `new`. It does not scrape NSE/BSE, access accounts, place orders, or send data anywhere. For authoritative material, obtain filings directly from NSE/BSE and relevant company disclosures, and check current SEBI requirements. Educational use only; not financial or legal advice.
