#!/usr/bin/env python3
"""Classify saved Indian exchange disclosure CSV/JSON rows; no scraping or advice."""
import argparse
import csv
import json
import os
import re
import sys


def load_rows(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        if path.lower().endswith(".json"):
            data = json.load(f)
            if isinstance(data, dict):
                data = data.get("data", data.get("rows", [data]))
            if not isinstance(data, list) or any(not isinstance(x, dict) for x in data):
                raise ValueError("JSON must contain an array of disclosure objects (or data/rows array)")
            return data
        return list(csv.DictReader(f))


def classify(row):
    text = " ".join(str(v) for v in row.values() if v is not None).lower()
    kinds = []
    if re.search(r"promoter|director|designated person|key managerial|insider", text):
        kinds.append("promoter/director/designated-person transaction")
    if re.search(r"sast|substantial shareholding|acquisition|disposal|takeover", text):
        kinds.append("substantial shareholding / SAST")
    if re.search(r"pledge|encumbrance|invocation|release of pledge", text):
        kinds.append("pledge / encumbrance")
    if re.search(r"shareholding pattern|holding pattern", text):
        kinds.append("shareholding pattern")
    return kinds or ["unclassified; inspect source filing"]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("scan", "new"))
    ap.add_argument("file", help="saved NSE/BSE CSV or JSON export")
    ap.add_argument("--state", default="trader/state/india-disclosures.json")
    a = ap.parse_args(argv)
    try:
        rows = load_rows(a.file)
        seen = set()
        if a.command == "new" and os.path.exists(a.state):
            with open(a.state, encoding="utf-8") as f:
                seen = set(json.load(f).get("fingerprints", []))
        import hashlib
        emitted = []
        for row in rows:
            canonical = json.dumps(row, sort_keys=True, ensure_ascii=False, default=str)
            key = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            if a.command == "new" and key in seen:
                continue
            emitted.append({"classification": classify(row), "source_row": row})
            seen.add(key)
        print(json.dumps(emitted, ensure_ascii=False, indent=2))
        if a.command == "new":
            os.makedirs(os.path.dirname(a.state) or ".", exist_ok=True)
            with open(a.state, "w", encoding="utf-8") as f:
                json.dump({"fingerprints": sorted(seen)}, f, ensure_ascii=False, indent=2)
                f.write("\n")
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as e:
        print("india_disclosures: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
