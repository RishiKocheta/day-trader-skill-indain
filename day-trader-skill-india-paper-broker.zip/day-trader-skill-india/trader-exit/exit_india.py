#!/usr/bin/env python3
"""Create an India cash-equity paper plan from the opening-range entry signal."""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india


def make_plan(signal, rr=1.0, flat_by="15:25"):
    if signal.get("status") != "triggered":
        raise india.IndiaDataError("entry signal is not triggered")
    entry = float(signal["entry"])
    high = float(signal["opening_range_high"])
    low = float(signal["opening_range_low"])
    side = signal.get("side", "buy")
    stop = (high + low) / 2.0
    if side == "buy":
        risk = entry - stop
        target = entry + rr * risk
    else:
        risk = stop - entry
        target = entry - rr * risk
    if risk <= 0:
        raise india.IndiaDataError("opening-range midpoint is on the wrong side of entry")
    return {"market": "India NSE/BSE cash equities", "symbol": signal["symbol"],
            "yahoo_symbol": signal.get("yahoo_symbol"), "exchange": signal.get("exchange", "NSE"),
            "date": signal["date"], "side": side, "entry": round(entry, 4),
            "entry_time_ist": signal.get("entry_time_ist", "09:30"),
            "stop": round(stop, 4), "target": round(target, 4), "risk_per_share": round(risk, 4),
            "reward_risk": float(rr), "flat_by_ist": flat_by, "currency": "INR",
            "setup": "15-minute opening-range breakout", "paper_only": True,
            "data_source": signal.get("source", "user-supplied entry signal"),
            "note": "Plan arithmetic only; stop fills can differ from the planned price."}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--entry", default="trader/entry.json")
    p.add_argument("--out", default="trader/plan-india.json")
    p.add_argument("--rr", type=float, default=1.0)
    p.add_argument("--flat-by", default="15:25", help="IST time before the 15:30 cash-market close")
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)
    try:
        with open(a.entry, encoding="utf-8") as f:
            signal = json.load(f)
        plan = make_plan(signal, a.rr, a.flat_by)
        india.write_json(a.out, plan)
        if a.json:
            print(json.dumps(plan, ensure_ascii=False, indent=2))
        else:
            print("PAPER PLAN %s %s: entry ₹%.2f, stop ₹%.2f, target ₹%.2f, flat by %s IST" %
                  (plan["side"].upper(), plan["symbol"], plan["entry"], plan["stop"], plan["target"], a.flat_by))
        return 0
    except (OSError, ValueError, india.IndiaDataError) as e:
        print("exit_india: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
