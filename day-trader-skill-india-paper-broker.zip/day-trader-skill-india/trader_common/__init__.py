"""Shared helpers for the India-focused workflow."""
