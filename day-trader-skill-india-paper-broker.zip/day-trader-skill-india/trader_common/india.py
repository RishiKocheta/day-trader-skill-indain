"""Small, dependency-free NSE/BSE cash-market data helpers.

Yahoo Finance is unofficial and may delay, omit, adjust, or rate-limit data.
This module does not scrape exchange websites or place orders.
"""
import datetime as dt
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

IST = dt.timezone(dt.timedelta(hours=5, minutes=30), "IST")
OPEN = dt.time(9, 15)
CLOSE = dt.time(15, 30)
UA = "Mozilla/5.0 (compatible; india-day-trader-skill/1.0)"


class IndiaDataError(Exception):
    pass


def parse_now(value=None):
    """Return naive UTC; an ISO time without offset is interpreted as IST."""
    if not value:
        return dt.datetime.now(dt.timezone.utc).replace(microsecond=0, tzinfo=None)
    text = str(value).strip().replace("Z", "+00:00")
    try:
        value = dt.datetime.fromisoformat(text)
    except ValueError:
        raise IndiaDataError("--now expects an ISO date/time in IST, such as 2026-10-30 10:15")
    if value.tzinfo is None:
        value = value.replace(tzinfo=IST)
    return value.astimezone(dt.timezone.utc).replace(microsecond=0, tzinfo=None)


def to_ist(value):
    if value.tzinfo is None:
        value = value.replace(tzinfo=dt.timezone.utc)
    return value.astimezone(IST)


def local_to_utc(value):
    return value.replace(tzinfo=IST).astimezone(dt.timezone.utc).replace(tzinfo=None)


def yahoo_symbol(symbol, exchange=None):
    sym = str(symbol).strip().upper()
    if not sym:
        raise IndiaDataError("symbol cannot be empty")
    if "." in sym or "=" in sym or "^" in sym:
        return sym
    suffix = ".BO" if str(exchange or "NSE").upper() == "BSE" else ".NS"
    return sym + suffix


def load_symbols(path):
    if not os.path.isfile(path):
        raise IndiaDataError("symbol list not found: %s (one NSE/BSE symbol per line)" % path)
    out = []
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if not line or line.lower() in ("symbol", "ticker"):
                continue
            sym = line.split(",", 1)[0].split("|", 1)[0].strip().upper()
            if sym and sym not in out:
                out.append(sym)
    if not out:
        raise IndiaDataError("symbol list is empty: %s" % path)
    return out


def chart_doc(symbol, interval="5m", period="5d", offline=None, exchange=None, timeout=20):
    ticker = yahoo_symbol(symbol, exchange)
    if offline:
        path = offline
        if os.path.isdir(path):
            candidates = [ticker, symbol, ticker.replace(".", "_")]
            path = next((os.path.join(offline, x + ".json") for x in candidates
                         if os.path.isfile(os.path.join(offline, x + ".json"))), "")
        if not path or not os.path.isfile(path):
            raise IndiaDataError("no offline chart fixture for %s" % ticker)
        try:
            with open(path, encoding="utf-8") as f:
                doc = json.load(f)
        except (OSError, ValueError) as e:
            raise IndiaDataError("cannot read chart fixture %s: %s" % (path, e))
    else:
        query = urllib.parse.urlencode({"range": period, "interval": interval, "events": "div,splits"})
        url = "https://query1.finance.yahoo.com/v8/finance/chart/%s?%s" % (urllib.parse.quote(ticker), query)
        request = urllib.request.Request(url, headers={"User-Agent": UA})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                doc = json.loads(response.read().decode("utf-8"))
        except (OSError, ValueError, urllib.error.URLError) as e:
            raise IndiaDataError("Yahoo chart request failed for %s: %s" % (ticker, e))
    try:
        result = doc["chart"]["result"][0]
        stamps = result.get("timestamp") or []
        quote = result["indicators"]["quote"][0]
    except (KeyError, IndexError, TypeError):
        err = (doc.get("chart") or {}).get("error") or {}
        raise IndiaDataError("no chart data for %s: %s" % (ticker, err.get("description", "invalid response")))
    bars = []
    for i, stamp in enumerate(stamps):
        try:
            values = {k: (quote.get(k) or [])[i] for k in ("open", "high", "low", "close", "volume")}
        except IndexError:
            continue
        if values["close"] is None:
            continue
        utc = dt.datetime.fromtimestamp(int(stamp), dt.timezone.utc)
        local = utc.astimezone(IST)
        bars.append({"time": local.strftime("%Y-%m-%d %H:%M:%S"), "date": local.date().isoformat(),
                     "hhmm": local.strftime("%H:%M"), "timestamp": int(stamp),
                     "open": values["open"], "high": values["high"], "low": values["low"],
                     "close": values["close"], "volume": values["volume"] or 0,
                     "currency": result.get("meta", {}).get("currency", "")})
    return {"symbol": symbol.upper(), "yahoo_symbol": ticker,
            "currency": result.get("meta", {}).get("currency", ""), "bars": bars,
            "source": "Yahoo Finance chart (unofficial)", "as_of": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")}


def trading_day(day, holidays_file="trader/india_holidays.json"):
    """Weekends are known; exchange closures require an official user-maintained date list."""
    if day.weekday() >= 5:
        return False, "weekend", False
    if os.path.isfile(holidays_file):
        try:
            with open(holidays_file, encoding="utf-8") as f:
                values = json.load(f).get("holidays", [])
            if not values:
                return True, "weekday; holiday list is empty and must be updated", False
            if day.isoformat() in values:
                return False, "listed exchange holiday", True
            return True, "weekday; checked against local holiday list", True
        except (OSError, ValueError, AttributeError):
            return True, "weekday; holiday file could not be read", False
    return True, "weekday; exchange holiday calendar not configured", False


def is_open(now_utc, holidays_file="trader/india_holidays.json"):
    local = to_ist(now_utc)
    is_day, reason, calendar_known = trading_day(local.date(), holidays_file)
    open_now = is_day and OPEN <= local.time().replace(tzinfo=None) < CLOSE
    return {"open": bool(open_now), "reason": reason, "calendar_known": calendar_known,
            "now_ist": local.strftime("%Y-%m-%d %H:%M:%S IST"), "opens": OPEN.strftime("%H:%M"),
            "closes": CLOSE.strftime("%H:%M"), "timezone": "Asia/Kolkata"}


def completed_bars(bars, now_utc, minutes=5):
    now = to_ist(now_utc).replace(tzinfo=None)
    out = []
    for bar in bars:
        start = dt.datetime.strptime(bar["time"], "%Y-%m-%d %H:%M:%S")
        if start + dt.timedelta(minutes=minutes) <= now:
            out.append(bar)
    return out


def rsi(values, n=14):
    if len(values) < n + 1:
        return None
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(x, 0.0) for x in changes[:n]]
    losses = [max(-x, 0.0) for x in changes[:n]]
    ag, al = sum(gains) / n, sum(losses) / n
    for change in changes[n:]:
        ag = (ag * (n - 1) + max(change, 0.0)) / n
        al = (al * (n - 1) + max(-change, 0.0)) / n
    return 100.0 if al == 0 else 100.0 - 100.0 / (1.0 + ag / al)


def write_json(path, value):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)
