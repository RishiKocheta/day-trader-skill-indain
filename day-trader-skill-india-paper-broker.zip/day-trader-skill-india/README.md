# Day Trader skills: India adaptation

An independent, India-focused adaptation of [Jake Schincariol's day-trader-skill](https://github.com/Jakeschincariol/day-trader-skill). It preserves all 11 original skill names and directories, retains the MIT license and upstream attribution, and adds India research tools.

**Scope:** NSE/BSE cash equities, INR, and Asia/Kolkata. This is an educational research and local simulation toolkit, not financial advice. The fork does not configure live credentials or enable live order execution. The India paper simulator has no broker connection. The inherited broker connector is US-specific; do not use it for Indian orders.

## India data and market limits

The original commands, fixtures, SEC feeds, congressional disclosure parser, and Alpaca/IBKR connector remain US-specific. Use the `_india.py` tools documented below for India workflows. Yahoo Finance charts and RSS are unofficial and may be delayed, incomplete, or adjusted. The scanner's editable symbol file is a sample, not complete exchange/index membership. The opening-range rules are simple educational examples, not an optimized strategy. Holiday status depends on a local user-maintained file; check current exchange notices, special sessions, and instrument rules.

## The eleven skills

| Skill | India workflow |
|---|---|
| `trader-scanner` | India daily setup and opening-range breakout scanner |
| `trader-news` | Yahoo Finance RSS or saved NSE/BSE disclosure files |
| `trader-entry` | 15-minute range and 5-minute breakout evaluation |
| `trader-exit` | INR stop, target, and flat-by plan |
| `trader-timemachine` | 10,000-run same-time historical path resampling and ORB history |
| `trader-risk` | INR daily loss and trade-count guard |
| `trader-budget` | INR sizing with risk, capital, and cost-buffer limits |
| `trader-broker` | Local hypothetical paper fills, never a broker connection |
| `trader-alerts` | India price threshold check; no background notification service |
| `trader-analyst` | Summarizes user-saved company facts with their source and period |
| `trader-pelosi` | India promoter/director disclosure classification; not a trading signal or US congressional tracker |

## Setup and one research pass

Requires Python 3.8+ and the standard library. Edit `trader/india_universe.txt`, then run from the repository root. The first scanner/replay/alert calls fetch Yahoo chart data; add `--offline path/to/chart.json` for offline chart fixtures. `entry_india.py` requires a chart fixture or network access through its command options.

```bash
python trader-scanner/scan_india.py orb
python trader-entry/entry_india.py RELIANCE --offline path/to/chart.json
python trader-exit/exit_india.py
python trader-budget/size_india.py --cash 250000 --risk-pct 0.5
python trader-risk/check_india.py --max-daily-loss 2500 --max-trades 3
python trader-broker/paper_india.py --price 1250
python trader-timemachine/timemachine_india.py --replays 10000
```

Each stage writes a JSON file under `trader/` for later inspection. The historical replay needs 20 complete sessions and resamples observed paths. Its results are not forecasts; it omits news, halts, gaps, costs, and changing market regimes. The simulator writes a hypothetical local fill only and never places an order.

### India disclosures

Save a public NSE/BSE disclosure export as CSV or JSON, then run:

```bash
python trader-pelosi/india_disclosures.py scan disclosures.csv
python trader-pelosi/india_disclosures.py new disclosures.csv --state trader/state/india-disclosures.json
```

The reader classifies promoter/director/designated-person trades, substantial shareholding/SAST changes, pledges/encumbrances, and shareholding patterns when fields are present. Exchange export schemas vary. Inspect the original filing; it is not an exhaustive feed and a missing row is not evidence that no disclosure exists. Indian public-company disclosures are legally and contextually different from US congressional PTRs; the retained folder name is for compatibility with the original eleven-skill set.

### News and company facts

```bash
python trader-news/news_india.py --symbol RELIANCE
python trader-news/news_india.py --file announcements.csv
python trader-analyst/facts_india.py company-facts.json
```

The company facts JSON must contain a `source` and a `facts` object. These tools preserve supplied information and do not independently verify exchange filings.

## Make this your own GitHub repository

1. Create a new empty repository under your GitHub account. Do not use the original author's repository URL.
2. Download and unzip this archive, then open a terminal in the extracted `day-trader-skill-india` folder.
3. Initialize and push to the URL GitHub gives your new repository:

```bash
git init
git add .
git commit -m "Create India-focused day trader skills fork"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-NEW-REPOSITORY.git
git push -u origin main
```

Replace the URL with your repository URL. Keep the included `LICENSE` and upstream attribution when redistributing.

## Safety and attribution

- Indian research scripts do not connect to a broker or execute live orders. The inherited broker integration remains US-specific and paper-only.
- Disclosures may be delayed, amended, incomplete, or filed under different categories. Promoter transactions do not indicate future price direction.
- Verify current exchange rules, trading sessions, costs, taxes, and data from official sources. Historical simulations and alerts do not predict or guarantee outcomes.
- Adapted from [Jake Schincariol's day-trader-skill](https://github.com/Jakeschincariol/day-trader-skill), copyright and MIT license retained. Independently maintained; not endorsed by the upstream author, NSE, BSE, or SEBI.

## Offline tests

```bash
python -m unittest discover -s tests -v
```
