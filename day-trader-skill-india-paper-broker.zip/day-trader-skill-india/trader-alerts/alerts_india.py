#!/usr/bin/env python3
"""Check INR price thresholds using Yahoo Finance chart data (unofficial)."""
import argparse,json,sys,os
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india

def evaluate(bars, above=None, below=None):
 if not bars: raise india.IndiaDataError('no price bars returned')
 price=float(bars[-1]['close']);hits=[]
 if above is not None and price>=float(above):hits.append('above')
 if below is not None and price<=float(below):hits.append('below')
 return {'price_inr':price,'time_ist':bars[-1]['time'],'triggered':bool(hits),'conditions':hits,'source':'Yahoo Finance chart (unofficial)','automated_notification':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('symbol');p.add_argument('--above',type=float);p.add_argument('--below',type=float);p.add_argument('--offline');p.add_argument('--out',default='trader/alert-india.json');a=p.parse_args()
 try:
  doc=india.chart_doc(a.symbol,'1m','1d',offline=a.offline);r=evaluate(doc['bars'],a.above,a.below);r.update({'symbol':a.symbol.upper(),'currency':'INR'});india.write_json(a.out,r);print(json.dumps(r,indent=2));return 0
 except (OSError,ValueError,KeyError,india.IndiaDataError) as e:print('alerts_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
