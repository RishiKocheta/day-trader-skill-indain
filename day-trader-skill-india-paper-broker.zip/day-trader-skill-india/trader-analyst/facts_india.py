#!/usr/bin/env python3
"""Summarize explicitly supplied, locally saved Indian company facts without estimating missing data."""
import argparse,json,sys

def summarize(doc):
 return {'company':doc.get('company'),'symbol':doc.get('symbol'),'period':doc.get('period'),
  'source':doc.get('source'),'facts':doc.get('facts',{}),'currency':doc.get('currency','INR'),
  'limitations':['User-supplied source facts are not independently verified.','No recommendation or forecast is produced.','Check original BSE/NSE/issuer filings and period definitions.']}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('file',help='JSON with company, period, source, and facts fields');a=p.parse_args()
 try:
  with open(a.file,encoding='utf8') as f:doc=json.load(f)
  if not isinstance(doc.get('facts'),dict) or not doc.get('source'):raise ValueError('JSON must include facts object and source citation')
  print(json.dumps(summarize(doc),ensure_ascii=False,indent=2));return 0
 except (OSError,ValueError) as e:print('facts_india: %s'%e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
