#!/usr/bin/env python3
"""Bootstrap 10,000 same-time-of-day historical NSE/BSE 5-minute paths."""
import argparse
import datetime as dt
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from trader_common import india


def by_session(bars):
    result = {}
    for bar in bars:
        if "09:15" <= bar["hhmm"] < "15:30":
            result.setdefault(bar["date"], []).append(bar)
    return {d: sorted(xs, key=lambda x: x["hhmm"]) for d, xs in result.items() if len(xs) >= 30}


def _orb_entry(bars):
    op = [b for b in bars if "09:15" <= b["hhmm"] < "09:30"]
    if len(op) < 3:
        return None
    high = max(float(b["high"]) for b in op)
    low = min(float(b["low"]) for b in op)
    for i, bar in enumerate(bars):
        if bar["hhmm"] >= "09:30" and float(bar["close"]) > high:
            entry = float(bar["close"])
            stop = (high + low) / 2.0
            if entry <= stop:
                return None
            return i, entry, stop, entry + (entry - stop), high, low
    return None


def _outcome(bars, index, entry, stop, target, side="buy", offset=0.0):
    for bar in bars[index:]:
        high, low = float(bar["high"]) + offset, float(bar["low"]) + offset
        if side == "buy":
            if low <= stop:
                return "stop"  # conservative when a single candle crosses both levels
            if high >= target:
                return "target"
        else:
            if high >= stop:
                return "stop"
            if low <= target:
                return "target"
    return "neither"


def replay(sessions, plan, replays=10000, seed=19):
    dates = sorted(sessions)
    if len(dates) < 20:
        raise india.IndiaDataError("need at least 20 complete Indian sessions; found %d" % len(dates))
    side = plan.get("side", "buy")
    entry, stop, target = float(plan["entry"]), float(plan["stop"]), float(plan["target"])
    entry_time = str(plan.get("entry_time_ist", "09:30"))[-8:-3]
    if not entry_time or ":" not in entry_time:
        entry_time = "09:30"
    replay_pool = []
    history = {"target": 0, "stop": 0, "neither": 0, "signals": 0}
    for day in dates:
        bars = sessions[day]
        candidate = _orb_entry(bars)
        if candidate:
            idx, hist_entry, hist_stop, hist_target, _, _ = candidate
            history["signals"] += 1
            history[_outcome(bars, idx + 1, hist_entry, hist_stop, hist_target)] += 1
        idx = next((i for i, b in enumerate(bars) if b["hhmm"] >= entry_time), None)
        if idx is not None and len(bars) - idx >= 2:
            replay_pool.append((bars, idx))
    if not replay_pool:
        raise india.IndiaDataError("historical sessions have no candles at/after the plan entry time")
    rng = random.Random(seed)
    counts = {"target": 0, "stop": 0, "neither": 0}
    for _ in range(int(replays)):
        bars, idx = replay_pool[rng.randrange(len(replay_pool))]
        base = float(bars[idx].get("open") or bars[idx]["close"])
        outcome = _outcome(bars, idx, entry, stop, target, side, entry - base)
        counts[outcome] += 1
    denominator = float(replays)
    return {"replays": int(replays), "seed": int(seed), "probabilities_pct":
            {k: round(v * 100.0 / denominator, 2) for k, v in counts.items()},
            "history": history, "historical_sessions": len(dates), "bootstrap_sessions": len(replay_pool),
            "method": "resample one observed same-time-of-day session path per replay; stop wins ambiguous same-bar touches",
            "warning": "Historical path resampling is a simulation, not a forecast. It omits news, halts, gaps, costs and changing market regimes."}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plan", default="trader/plan-india.json")
    p.add_argument("--offline", help="offline Yahoo chart JSON")
    p.add_argument("--replays", type=int, default=10000)
    p.add_argument("--seed", type=int, default=19)
    p.add_argument("--now", help="ISO time; offset-free values are IST")
    p.add_argument("--out", default="trader/timemachine-india.json")
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)
    try:
        with open(a.plan, encoding="utf-8") as f:
            plan = json.load(f)
        doc = india.chart_doc(plan["symbol"], "5m", "60d", offline=a.offline)
        now_day = india.to_ist(india.parse_now(a.now)).date().isoformat()
        bars = [b for b in doc["bars"] if b["date"] < now_day]
        result = replay(by_session(bars), plan, a.replays, a.seed)
        result.update({"symbol": plan["symbol"], "currency": "INR", "source": doc["source"],
                       "as_of_ist": india.to_ist(india.parse_now(a.now)).isoformat()})
        india.write_json(a.out, result)
        if a.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            odds = result["probabilities_pct"]
            print("%s: target first %.1f%%, stop first %.1f%%, still open %.1f%% across %d resampled sessions." %
                  (plan["symbol"], odds["target"], odds["stop"], odds["neither"], result["replays"]))
            print("Historical ORB setups: %(signals)d; targets %(target)d, stops %(stop)d, neither %(neither)d." % result["history"])
            print(result["warning"])
        return 0
    except (OSError, ValueError, KeyError, india.IndiaDataError) as e:
        print("timemachine_india: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
